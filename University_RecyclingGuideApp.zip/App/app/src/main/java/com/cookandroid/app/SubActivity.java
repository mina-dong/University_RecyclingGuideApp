package com.cookandroid.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends Activity {

    ImageView Img_pla, Img_paper, Img_glass, Img_can, Img_pcv, Img_clothes, Img_battery, Img_light, Img_poly;
    Button Btnshortcut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        Img_pla = findViewById(R.id.img_plastic);
        Img_paper = findViewById(R.id.img_paper);
        Img_glass = findViewById(R.id.img_glass);
        Img_can = findViewById(R.id.img_can);
        Img_pcv = findViewById(R.id.img_pcvbag);
        Img_clothes = findViewById(R.id.img_clothes);
        Img_battery = findViewById(R.id.img_battery);
        Img_light = findViewById(R.id.img_light);
        Img_poly = findViewById(R.id.img_poly);

        Btnshortcut= findViewById(R.id.btnshortcut);

        //플라스틱 팝업
        Img_pla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("플라스틱 배출 방법");
                builder.setMessage("내용물을 깨끗이 비우고 부착상표(라벨) 등을 제거한 후 가능한 압착하여 뚜껑을 닫아 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "플라스틱 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //종이 팝업
        Img_paper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("종이 배출 방법");
                builder.setMessage("내용물을 비우고 물로 헹구는 등 이물질을 제거하고 말린 후 배출하고 다른 재질은 제거하여 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "종이 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //유리 팝업
        Img_glass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("유리 배출 방법");
                builder.setMessage("담배꽁초 등 이물질을 넣지 않고 유리병이 깨지지 않도록 주의하여, 내용물을 비우고 물로 헹궈 이물질을 제거해 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "유리 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //캔 팝업
        Img_can.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("캔 배출 방법");
                builder.setMessage(" 내용물을 비우고 물로 헹구는 등 이물질을 제거하고 플라스틱 뚜껑 등 금속캔과 다른 재질은 제거한 후 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "플라스틱 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //비닐봉지 팝업
        Img_pcv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("비닐봉지 배출 방법");
                builder.setMessage("내용물을 비우고 물로 헹구는 등 이물질을 제거하고 흩날리지 않도록 투명 또는 반투명 봉투에 담아 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "비닐봉투 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //의류 팝업
        Img_clothes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("의류 배출 방법");
                builder.setMessage("지자체 또는 민간 재활용사업자가 비치한 폐의류 전용수거함에 배출하거나 문전수거 지역 등에서는 물기에 젖지 않도록 마대 등에 담거나 묶어서 대문 앞 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "의류 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //건전지 팝업
        Img_battery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("건전지 배출 방법");
                builder.setMessage("전지를 제품에서 분리하고 전자제품 대리점 및 시계점 또는 비치된 수거함에 배출합니다. ");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "건전지 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //형광등 팝업
        Img_light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("형광등 배출 방법");
                builder.setMessage("지자체별 형광등 분리배출용기에 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "형광등 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });

        //스티로폼 팝업
        Img_poly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);

                builder.setTitle("스티로폼 배출 방법");
                builder.setMessage("내용물을 비우고, 이물질과 부착상표 등 스티로폼과 다른 재질은 제거한 후 배출합니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(SubActivity.this, "스티로폼 분리가이드 안내 종료합니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
            }
        });


        //인터넷 바로가기
        Btnshortcut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.daejeon.go.kr/drh/DrhContentsHtmlView.do?menuSeq=1976"));
                startActivity(intent);
            }


        });

    }
}
